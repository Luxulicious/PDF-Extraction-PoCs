﻿using System;

namespace BuildTablesFromPdf.Engine.Statements
{
    class SingleLineStatement : Statement
    {
        public string RawContent { get; set; }
    }
}
