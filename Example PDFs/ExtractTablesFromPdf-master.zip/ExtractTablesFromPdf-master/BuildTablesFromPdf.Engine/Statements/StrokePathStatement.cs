﻿namespace BuildTablesFromPdf.Engine.Statements
{
    internal class StrokePathStatement : SingleLineStatement
    {
        public static readonly StrokePathStatement Value = new StrokePathStatement();
    }
}