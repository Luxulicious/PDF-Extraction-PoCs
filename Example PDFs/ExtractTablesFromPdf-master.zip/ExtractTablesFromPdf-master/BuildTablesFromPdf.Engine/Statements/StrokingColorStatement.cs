﻿namespace BuildTablesFromPdf.Engine.Statements
{
    class StrokingColorStatement : ColorStatement
    {
        public StrokingColorStatement(string rawContent)
        {
            RawContent = rawContent;
        }
    }
}