namespace BuildTablesFromPdf.Engine.Statements
{
    internal class FillPathStatement : SingleLineStatement
    {
        public static readonly FillPathStatement Value = new FillPathStatement();
    }
}