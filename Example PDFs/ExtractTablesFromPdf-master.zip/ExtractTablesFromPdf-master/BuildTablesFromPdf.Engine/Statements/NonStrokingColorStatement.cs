﻿namespace BuildTablesFromPdf.Engine.Statements
{
    class NonStrokingColorStatement : ColorStatement
    {
        public NonStrokingColorStatement(string rawContent)
        {
            RawContent = rawContent;
        }
    }
}