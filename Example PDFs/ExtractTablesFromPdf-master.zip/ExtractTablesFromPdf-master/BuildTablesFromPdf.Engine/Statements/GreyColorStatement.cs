﻿namespace BuildTablesFromPdf.Engine.Statements
{
    internal class GreyColorStatement : ColorStatement
    {
        public GreyColorStatement(string rawContent)
        {
            RawContent = rawContent;
        }
    }
}