namespace BuildTablesFromPdf.Engine.Statements
{
    internal class CloseStrokePathStatement : SingleLineStatement
    {
        public static readonly CloseStrokePathStatement Value = new CloseStrokePathStatement();
    }
}