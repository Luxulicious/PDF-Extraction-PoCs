﻿namespace BuildTablesFromPdf.Engine.Statements
{
    class PointStatement : SingleLineStatement
    {
    }
}